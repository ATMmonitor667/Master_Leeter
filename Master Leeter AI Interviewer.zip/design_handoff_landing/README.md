# Handoff: Master Leeter marketing landing page

## Overview
A public marketing landing page for Master Leeter — a voice-first AI technical interview simulator. The page sells the product, demonstrates the interview experience with an interactive fake code panel, and routes visitors into the existing session-setup flow.

Target repo: `ATMmonitor667/Master_Leeter`, branch `main`, app `apps/web` (Next.js 15 App Router, React 19, TypeScript, plain CSS + inline styles — no Tailwind, no component library).

## About the design files
`master-leeter-standalone.html` and `Master Leeter.dc.html` in this bundle are **design references written in HTML** — prototypes of the intended look and behavior. They are not production code to copy. Recreate them as React/Next.js components in `apps/web`, using the repo's existing conventions: `"use client"` only where needed, CSS custom properties in `app/globals.css`, inline `style={{}}` objects for component-local styling (that is how every existing component in `apps/web/components` does it).

Open `master-leeter-standalone.html` in a browser to see the real thing, including the animations.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions. Recreate pixel-accurately. Every hex value, size, and duration below is exact.

---

## Screens / views

### 1. Landing page — route `/`

Replaces the current `apps/web/app/page.tsx`. The existing scenario picker (fetches `${API}/v1/scenarios`, mode `<select>`, POSTs `/v1/interview-sessions` with an idempotency key, redirects to `/interview/${sessionId}`) **must be preserved** — move it verbatim to `apps/web/app/start/page.tsx`. Every CTA on the landing page links to `/start`.

Page shell: `position: relative; min-height: 100vh; background: #08090c; color: #e6e8ee; font-family: 'Space Grotesk', Helvetica, sans-serif; overflow-x: hidden`.

Two fixed background layers sit behind everything:
- `<NetworkBackdrop />` — canvas, `position: fixed; inset: 0; width: 100%; height: 100%; z-index: 0; opacity: .55`
- A non-interactive glow layer, `position: fixed; inset: 0; z-index: 1; pointer-events: none`, background:
  `radial-gradient(900px 500px at 20% 0%, rgba(127,227,194,.10), transparent 60%), radial-gradient(700px 500px at 85% 15%, rgba(150,140,255,.10), transparent 60%)`

All content sits in a `position: relative; z-index: 2` wrapper.

#### 1a. Nav (sticky)
`display: flex; align-items: center; justify-content: space-between; padding: 20px 40px; border-bottom: 1px solid rgba(255,255,255,.06); backdrop-filter: blur(8px); position: sticky; top: 0; background: rgba(8,9,12,.72); z-index: 10`.

Left cluster — `display: flex; align-items: center; gap: 10px`:
- Logo mark: `26×26px`, `border-radius: 8px`, `background: linear-gradient(140deg, #7fe3c2, #8f8bff)`, `box-shadow: 0 0 24px rgba(127,227,194,.45)`
- Wordmark "Master Leeter": `font-weight: 700; letter-spacing: -.02em; font-size: 17px`
- Badge "beta": JetBrains Mono, `font-size: 10px; letter-spacing: .14em; text-transform: uppercase; color: #7fe3c2; border: 1px solid rgba(127,227,194,.3); padding: 3px 7px; border-radius: 999px; margin-left: 6px`

Right cluster — `display: flex; align-items: center; gap: 28px; font-size: 14px; color: #9aa1b1`:
- Links: "Practice" (`#practice`), "How it works" (`#how`), "Pricing" (`#pricing`). Hover → `color: #e6e8ee`.
- Primary button "Start mock interview" → `/start`. See **Button styles** below.

#### 1b. Hero
`max-width: 1240px; margin: 0 auto; padding: 90px 40px 40px; display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 56px; align-items: center`.

**Left column:**
- Eyebrow pill: `display: inline-flex; align-items: center; gap: 8px`, JetBrains Mono `11px`, `letter-spacing: .12em; text-transform: uppercase; color: #8f8bff; border: 1px solid rgba(143,139,255,.28); background: rgba(143,139,255,.07); padding: 6px 12px; border-radius: 999px`. Contains a `6×6px` circle `background: #8f8bff` with `animation: pulseDot 1.6s infinite`, then the text "Live voice + code interviewer".
- H1: `font-size: clamp(42px, 4.4vw, 66px); line-height: 1.02; letter-spacing: -.035em; font-weight: 700; margin: 22px 0 0; text-wrap: balance`. Copy, with a hard `<br>`:
  `Get grilled on DSA` / `before they do it.`
- Sub: `font-size: 18px; line-height: 1.6; color: #9aa1b1; max-width: 480px; margin: 20px 0 0; text-wrap: pretty`. Copy: "An AI interviewer that watches you type, interrupts your brute force, asks for the complexity, and writes the feedback report your friends won't."
- Button row: `display: flex; gap: 12px; margin-top: 32px` — primary "Run a free mock →" (→ `/start`), ghost "Watch 90s demo".
- Stats row: `display: flex; gap: 34px; margin-top: 44px`, JetBrains Mono. Three items, each a value (`font-size: 24px; font-weight: 600; color: #e6e8ee`) over a label (`font-size: 11px; letter-spacing: .1em; text-transform: uppercase; color: #6b7385; margin-top: 4px`): **1,842** / problems · **28 min** / avg session · **4.9★** / rating. *(Placeholder numbers — swap for real ones or cut the row.)*

**Right column:** the demo code panel, id `practice`, `position: relative; animation: floaty 9s ease-in-out infinite`. See section 2.

#### 1c. Topic ticker
Full-bleed strip. Outer: `overflow: hidden; border-top: 1px solid rgba(255,255,255,.06); border-bottom: 1px solid rgba(255,255,255,.06); margin-top: 70px; background: rgba(255,255,255,.015)`.
Inner: `display: flex; width: max-content; animation: marquee 34s linear infinite`, JetBrains Mono `12px`, `letter-spacing: .16em; text-transform: uppercase; color: #4d5464; padding: 14px 0`. Each item `padding: 0 26px`.

Items (the list is **duplicated once** so the loop is seamless — `marquee` translates `-50%`): two pointers, graphs, dp on trees, sliding window, union find, heaps, backtracking, tries, binary search, topological sort.

#### 1d. Feature grid — id `how`
`max-width: 1240px; margin: 0 auto; padding: 100px 40px 40px`.

H2: `font-size: 40px; letter-spacing: -.03em; font-weight: 600; margin: 0`, copy with a `<br>`: `The parts of an interview` / `a judge score can't fake.`

Grid: `display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; margin-top: 44px`. *(Make this `repeat(auto-fit, minmax(280px, 1fr))` when you wire up responsive.)*

Card: `position: relative; overflow: hidden; border: 1px solid rgba(255,255,255,.08); border-radius: 14px; background: rgba(255,255,255,.025); padding: 26px 24px 28px; transition: border-color .25s, transform .25s, background .25s`.
Hover: `border-color: rgba(127,227,194,.3); transform: translateY(-3px); background: rgba(127,227,194,.04)`.
Contents: number (JetBrains Mono `11px`, `color: #7fe3c2; letter-spacing: .14em`), title (`font-size: 19px; font-weight: 600; margin-top: 14px; letter-spacing: -.01em`), body (`font-size: 14px; line-height: 1.6; color: #9aa1b1; margin-top: 9px; text-wrap: pretty`).

Exact copy:
| # | Title | Body |
| --- | --- | --- |
| 01 | It interrupts you | Ten minutes of silent brute force gets a question, not a green checkmark. Same as a real loop. |
| 02 | Complexity on demand | Every submission ends with 'why is that O(n log n)?' — and it knows when you're guessing. |
| 03 | Voice or text | Talk through it like a phone screen, or type if you're in a library. Transcript either way. |
| 04 | Weakness map | Ten sessions in, it knows you fold on graph problems after minute twenty. It'll say so. |
| 05 | Company modes | Tune the interviewer's pressure, hint policy, and follow-up depth to the bar you're targeting. |
| 06 | Replay any session | Scrub your own keystrokes back with the interviewer's notes pinned to the moment you stalled. |

#### 1e. CTA band + footer — id `pricing`
Section: `max-width: 1240px; margin: 0 auto; padding: 90px 40px 120px`.

Band: `position: relative; overflow: hidden; border: 1px solid rgba(127,227,194,.22); border-radius: 20px; background: linear-gradient(140deg, rgba(127,227,194,.09), rgba(143,139,255,.06)); padding: 60px 48px; text-align: center`.
Inside, a shine element: `position: absolute; top: 0; bottom: 0; width: 180px; background: linear-gradient(90deg, transparent, rgba(255,255,255,.06), transparent); animation: sweep 6s linear infinite`.
- H2 `font-size: 44px; letter-spacing: -.03em; font-weight: 700; margin: 0` — "Your next loop starts in 3 weeks."
- P `color: #9aa1b1; font-size: 17px; margin: 16px auto 0; max-width: 520px` — "Unlimited mock interviews, full transcripts, and a weakness map. $19/mo, cancel whenever."
- Primary button `margin-top: 30px; padding: 15px 30px` — "Start free — 3 interviews"

⚠️ **Pricing copy is invented.** Replace `$19/mo` and "3 interviews" with real numbers before shipping, or cut the section to a single CTA.

Footer: `display: flex; justify-content: space-between; align-items: center; margin-top: 60px; padding-top: 26px; border-top: 1px solid rgba(255,255,255,.06); font-size: 13px; color: #575e6e`. Left "© 2026 Master Leeter", right (JetBrains Mono) "built for people who freeze on the whiteboard".

---

### 2. `<DemoCodePanel />` — the interactive mock

`"use client"`. **Do not use Monaco here.** `@monaco-editor/react` is already a dependency for the real interview screen, but it is ~1MB of JS and this panel never accepts input — it is a picture that reacts to clicks. Render pre-tokenized lines as spans.

Glow: an absolutely positioned sibling, `inset: -1px; border-radius: 18px; background: linear-gradient(140deg, rgba(127,227,194,.5), rgba(143,139,255,.35), transparent 70%); filter: blur(14px); opacity: .5`.

Panel: `position: relative; border: 1px solid rgba(255,255,255,.1); border-radius: 16px; background: #0c0e13; overflow: hidden; box-shadow: 0 30px 80px rgba(0,0,0,.6)`.

**Title bar** — `display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; border-bottom: 1px solid rgba(255,255,255,.07); background: rgba(255,255,255,.02)`:
- Three `10×10px` circles, `gap: 7px`: `#ff5f57`, `#febc2e`, `#28c840`
- Filename, JetBrains Mono `12px`, `color: #6b7385; margin-left: 10px`: `two-sum-ii.{ext}` where ext = `py` | `js` | `cpp`, driven by the language tab
- Language segmented control, right-aligned

**Toolbar row** — `display: flex; align-items: center; justify-content: space-between; padding: 10px 14px; border-bottom: 1px solid rgba(255,255,255,.07)`:
- Left: difficulty segmented control — Easy / Medium / Hard, default **Medium**
- Right: two toggles, `gap: 14px`, each `display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12px; color: #9aa1b1`, JetBrains Mono, labels `hints` and `voice`, both default **on**

**Segmented control** (both instances): container `display: flex; gap: 4px; padding: 3px; background: rgba(255,255,255,.05); border-radius: 9px`. Each button: JetBrains Mono `11px`, `padding: 5px 11px; border-radius: 7px; border: none; cursor: pointer; transition: all .18s`.
- Active: `background: rgba(127,227,194,.16); color: #7fe3c2; box-shadow: inset 0 0 0 1px rgba(127,227,194,.35)`
- Inactive: `background: transparent; color: #6b7385`

**Toggle switch**: track `width: 34px; height: 19px; border-radius: 999px; padding: 2px; transition: background .2s`. On → `background: #7fe3c2` (hints) / `#8f8bff` (voice); off → `rgba(255,255,255,.12)`. Knob `15×15px; border-radius: 50%; background: #08090c; transition: transform .2s; transform: translateX(15px)` when on, `translateX(0)` when off.

**Code area** — `display: grid; grid-template-columns: 34px 1fr`, JetBrains Mono `13px; line-height: 1.75; padding: 16px 14px 18px; min-height: 250px`.
- Gutter: `color: #3a4050; text-align: right; padding-right: 12px`, one `<div>` per line number.
- Code column: `color: #cbd2e0`. **Each line is its own `<div style={{ whiteSpace: "pre" }}>`** — putting `white-space: pre` on the parent renders the JSX whitespace between lines and breaks gutter alignment (this bug was hit and fixed during design).
- After the last line, a caret: `display: inline-block; width: 8px; height: 16px; background: #7fe3c2; vertical-align: -3px; animation: blink 1.1s step-end infinite`.

Token colors: keyword `#8f8bff` · function name `#7fe3c2` · number `#e0a0ff` · plain `#cbd2e0` · comment `#4d5464`.

The three snippets are all two-pointer Two Sum II (sorted array), each ending in a `O(n) time, O(1) space` comment — lift them verbatim from `Master Leeter.dc.html`'s `code()` method, which stores them as `[text, tokenType]` pairs per line.

**Interviewer footer** — `border-top: 1px solid rgba(255,255,255,.07); background: rgba(255,255,255,.02); padding: 14px`:
- Header row (`gap: 10px; margin-bottom: 12px`): `22×22px` gradient chip (`linear-gradient(140deg, #7fe3c2, #8f8bff)`, `border-radius: 7px`), label "interviewer" (JetBrains Mono `12px`, `color: #6b7385; letter-spacing: .08em; text-transform: uppercase`), a `flex: 1` hairline `rgba(255,255,255,.07)`, then the timer (JetBrains Mono `12px`).
- Timer starts at `18:12` and counts **up** every second. Color `#6b7385`, switching to `#ff8b6b` past 25:00. ⚠️ See "Conflicts" below.
- Message bubbles, `font-size: 13.5px; line-height: 1.6; padding: 11px 13px; border-radius: 11px; margin-bottom: 8px; text-wrap: pretty`:
  - interviewer: `color: #cbd2e0; background: rgba(143,139,255,.08); border: 1px solid rgba(143,139,255,.16)`
  - candidate: `color: #9aa1b1; background: rgba(255,255,255,.035); border: 1px solid rgba(255,255,255,.07)`
- Seed transcript (2 messages): AI — "Walk me through your approach before you type. What's the invariant that lets you move the pointers?" then candidate — "Sorted array — if the sum is too big I shrink from the right."
- Button row `display: flex; gap: 8px; margin-top: 14px`: primary `flex: 1` labelled `run tests  ⌘↵` (JetBrains Mono `13px`), ghost "nudge me".

**Panel interactions:**
- Language tab → swaps the snippet, line count, and filename extension.
- Difficulty tab / both toggles → visual state only.
- `run tests` → label becomes `running tests…`, disabled for 1100ms, then appends the AI line: "All 61 tests pass. Now: what breaks if the array isn't sorted, and what would you reach for instead?"
- `nudge me` → appends: "You're scanning every pair. The array is sorted — that's a fact you haven't spent yet."
- Both keep only the **last 2 prior messages** before appending, so the panel never grows and shifts the page.

---

### 3. `<NetworkBackdrop />` — the moving graphic

`"use client"`, canvas, single `requestAnimationFrame` loop.

- 46 nodes, each: random position, velocity `(Math.random() - .5) * .28` per axis, radius `Math.random() * 1.6 + .7`
- Bounce by flipping velocity at the edges
- Edge between every pair closer than `150px`: `strokeStyle = rgba(127,227,194, 0.16 * (1 - d/150))`, `lineWidth: 1`
- Node fill `rgba(160,200,255,.32)`
- DPR: `Math.min(window.devicePixelRatio || 1, 2)`, applied via `ctx.setTransform(dpr, 0, 0, dpr, 0, 0)`
- Resize listener recomputes size; **cleanup must** `cancelAnimationFrame` and remove the listener on unmount
- Under `prefers-reduced-motion: reduce`, draw one static frame and stop

O(n²) at n=46 is ~1035 distance checks per frame — fine. Don't raise the node count much.

---

## Design tokens

Add to `apps/web/app/globals.css` as a **separate marketing scale**; do not change the existing app tokens (`--bg: #0f1115`, `--accent: #6ea8fe`, etc.), since the interview and report screens depend on them.

```css
:root {
  --mkt-bg: #08090c;
  --mkt-panel: #0c0e13;
  --mkt-border: rgba(255, 255, 255, 0.08);
  --mkt-text: #e6e8ee;
  --mkt-muted: #9aa1b1;
  --mkt-dim: #6b7385;
  --mkt-faint: #4d5464;
  --mkt-accent: #7fe3c2;
  --mkt-accent-2: #8f8bff;
  --mkt-num: #e0a0ff;
}
```

Type scale (px): 10, 11, 12, 13, 13.5, 14, 15, 17, 18, 19, 24, 40, 44, clamp(42–66).
Radii (px): 7, 8, 9, 10, 11, 12, 14, 16, 20, 999.
Spacing: multiples of 4, mostly 8–56. Section padding `90–100px 40px`.

**Fonts** — Space Grotesk (400/500/600/700) for UI, JetBrains Mono (400/500/600) for code, labels, stats, and eyebrows. Load with `next/font/google` in `app/layout.tsx` and expose as CSS variables; do not use a `<link>` tag. Note the app currently uses `system-ui` and `--mono: ui-monospace…` — scope the new families to the landing route group so the interview UI is unaffected, unless you want them product-wide.

### Button styles
- **Primary**: `color: #08090c; background: #7fe3c2; border: none; border-radius: 10–12px; font-weight: 600; cursor: pointer; transition: transform .15s, box-shadow .25s`. Padding: `10px 18px` (nav), `14px 24px` (hero), `15px 30px` (CTA band). Hover: `transform: translateY(-1px); box-shadow: 0 8px 30px rgba(127,227,194,.35)`.
- **Ghost**: `color: #e6e8ee; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.12); border-radius: 12px; padding: 14px 24px; transition: background .2s`. Hover: `background: rgba(255,255,255,.09)`.

Note the repo's `globals.css` sets a global `button` style (`background: var(--panel); border: 1px solid var(--border)`). Landing buttons must override it — either scope the global rule or give landing buttons an explicit class.

### Keyframes
```css
@keyframes blink    { 0%,49% { opacity: 1 } 50%,100% { opacity: 0 } }
@keyframes floaty   { 0% { transform: translateY(0) } 50% { transform: translateY(-10px) } 100% { transform: translateY(0) } }
@keyframes sweep    { 0% { transform: translateX(-120%) } 100% { transform: translateX(220%) } }
@keyframes pulseDot { 0%,100% { opacity: .35; transform: scale(.85) } 50% { opacity: 1; transform: scale(1.15) } }
@keyframes marquee  { 0% { transform: translateX(0) } 100% { transform: translateX(-50%) } }
```
All are decorative — wrap them in `@media (prefers-reduced-motion: no-preference)`.

---

## State

All local, no fetching. `DemoCodePanel` owns:

| State | Type | Default |
| --- | --- | --- |
| `lang` | `"Python" \| "JS" \| "C++"` | `"Python"` |
| `diff` | `"Easy" \| "Medium" \| "Hard"` | `"Medium"` |
| `hints` | boolean | `true` |
| `voice` | boolean | `true` |
| `seconds` | number (counts up, 1s interval) | `1092` (= 18:12) |
| `running` | boolean | `false` |
| `chat` | `{ who: "ai" \| "you", text: string }[]` | the 2 seed messages |

`NetworkBackdrop` holds no React state — everything lives in the rAF closure.

---

## Responsive

Only the hero is currently responsive (`repeat(auto-fit, minmax(420px, 1fr))` + `clamp()` H1). Still to do:
- Feature grid → `repeat(auto-fit, minmax(280px, 1fr))`
- Nav → collapse links below ~720px, keep the CTA
- Section padding → `40px 20px` on mobile
- Stats row → allow wrapping
- Consider hiding the canvas below ~640px (battery)

---

## Two conflicts with the app's stated design principles

Your own component comments reject both of these; the landing does them anyway because a static dot doesn't sell on a webpage. Decide before shipping:

1. **Transcript.** `components/InterviewerStatus.tsx` says a transcript "would turn a listening exercise back into a reading one, which is the thing this product exists not to be." The demo panel shows one. Either accept it as marketing shorthand, or replace the bubbles with a waveform + status pill so the page doesn't promise a UI the app won't have. (Feature card 03 also says "Transcript either way" — same call.)
2. **Timer color.** `components/Timer.tsx` says "No colour changes, no urgency animation, no gamification." The demo turns the clock `#ff8b6b` past 25:00. Also, the real timer counts **down** from a server-authoritative value; the demo counts **up**. Drop the color change if the no-pressure stance is real.

---

## Assets
None. No images, no icon fonts, no SVG illustrations. Every visual is CSS, canvas, or a Unicode character (`→`, `★`, `⌘↵`).

## Files in this bundle
- `master-leeter-standalone.html` — self-contained build, open in any browser. **Start here.**
- `Master Leeter.dc.html` — authoring source. The markup lives in the `<x-dc>` body; state, code snippets, and style helpers live in the `<script>` class at the bottom (`code()` has the three language snippets, `seg()` and `toggle()` the control styles, `renderVals()` everything else).
- `CLAUDE_CODE_PROMPT.md` — paste into Claude Code in the repo root.

## Repo files this touches
- `apps/web/app/page.tsx` — replaced by the landing page
- `apps/web/app/start/page.tsx` — **new**, receives the current `page.tsx` content unchanged
- `apps/web/app/layout.tsx` — fonts
- `apps/web/app/globals.css` — marketing tokens, keyframes, button-rule scoping
- `apps/web/components/NetworkBackdrop.tsx` — new
- `apps/web/components/DemoCodePanel.tsx` — new

Untouched: `/interview/[sessionId]`, `/report/[sessionId]`, `lib/*`, `apps/api`, `packages/contracts`.
