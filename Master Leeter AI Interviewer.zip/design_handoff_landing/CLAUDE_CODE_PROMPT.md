# Claude Code prompt

Run this from the root of `ATMmonitor667/Master_Leeter`, with `design_handoff_landing/` copied somewhere you can point at (repo root is fine — add it to `.gitignore` or delete it after). Paste everything below the line.

---

I'm adding a marketing landing page to `apps/web`. The design already exists as an HTML prototype in `design_handoff_landing/`.

**Read these first, in order:**
1. `design_handoff_landing/README.md` — the full spec: every screen, exact hex values, typography, spacing, animations, state, and copy. This is the source of truth.
2. `design_handoff_landing/master-leeter-standalone.html` — the working prototype. Open it in a browser to see the animations and interactions.
3. `design_handoff_landing/Master Leeter.dc.html` — the authoring source. Its `<script>` class at the bottom holds the three code snippets (`code()`), the segmented-control and toggle styles (`seg()`, `toggle()`), and all the copy.

Then read the existing app so the new code matches it: `apps/web/app/page.tsx`, `apps/web/app/layout.tsx`, `apps/web/app/globals.css`, and `apps/web/components/InterviewerStatus.tsx` + `Timer.tsx` (for the house style — `"use client"`, inline `style={{}}` objects, CSS custom properties, explanatory comments about *why* a decision was made).

**The HTML files are design references, not code to copy.** Recreate the design as Next.js 15 / React 19 / TypeScript components using this repo's conventions. No Tailwind, no new UI libraries, no new dependencies at all.

## What to build

1. **Move the existing session setup.** The current `apps/web/app/page.tsx` (scenario catalogue, mode select, `POST /v1/interview-sessions` with idempotency key, redirect to `/interview/${sessionId}`) moves **verbatim** to `apps/web/app/start/page.tsx`. Do not change its behavior. Every CTA on the new landing page links to `/start`.

2. **New landing page at `apps/web/app/page.tsx`** — nav, hero, topic ticker, 6-card feature grid, CTA band, footer. Server component where possible; only the two pieces below are client components.

3. **`apps/web/components/NetworkBackdrop.tsx`** — the animated canvas backdrop. Spec in README §3. Must clean up its rAF and resize listener on unmount, and must respect `prefers-reduced-motion`.

4. **`apps/web/components/DemoCodePanel.tsx`** — the interactive fake code editor: language tabs, difficulty tabs, two toggle switches, syntax-highlighted static code, a live timer, an interviewer transcript, and two buttons that append canned lines. Spec in README §2.
   **Do not use Monaco for this.** `@monaco-editor/react` stays reserved for the real interview screen — the demo panel never takes input and shouldn't ship a megabyte of JS to the marketing page. Render pre-tokenized lines as spans.
   One gotcha the README calls out: put `whiteSpace: "pre"` on **each code line div**, not on the parent container, or JSX whitespace renders as blank lines and the gutter numbers desync.

5. **`apps/web/app/globals.css`** — add the `--mkt-*` token block and the five keyframes from README "Design tokens". Do not modify the existing `--bg` / `--panel` / `--accent` values; the interview and report screens depend on them. The existing global `button { … }` rule will fight the landing buttons — scope it or give the landing buttons their own class, whichever is cleaner.

6. **`apps/web/app/layout.tsx`** — load Space Grotesk (400/500/600/700) and JetBrains Mono (400/500/600) with `next/font/google`, exposed as CSS variables. Scope them so the interview UI keeps its current `system-ui` stack.

## Constraints

- No new dependencies.
- `pnpm --filter @master-leeter/web typecheck` and `pnpm --filter @master-leeter/web build` must pass.
- Match the exact hex values, sizes, and copy in the README. It's a high-fidelity spec, not a mood board.
- No images or SVG illustrations — everything is CSS, canvas, or Unicode.

## Two things to flag, not silently decide

The README §"Two conflicts" documents these; surface them and ask me rather than picking:

1. The demo panel shows an interviewer **transcript**, but `InterviewerStatus.tsx` explicitly argues against transcripts in the product.
2. The demo timer counts **up** and turns orange past 25:00, but `Timer.tsx` explicitly rejects urgency cues and counts **down** from a server value.

Build the landing as specced, then tell me both so I can decide whether the marketing page should promise them.

Also: the stats row (1,842 problems / 28 min / 4.9★) and the pricing copy ($19/mo, 3 free interviews) are **invented placeholders**. Leave them in, but list them at the end so I can replace them with real numbers.

Start by reading the files, then show me your plan before writing anything.
